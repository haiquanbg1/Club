module.exports = {
    user: 1,
    manager: 2
}